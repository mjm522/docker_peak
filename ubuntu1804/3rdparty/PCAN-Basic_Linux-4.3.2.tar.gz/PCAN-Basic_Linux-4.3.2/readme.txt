===============================================================================
ReadMe.txt

PCAN-Basic Linux V4.2.1
Copyright (c) 2019 PEAK-System Technik GmbH Darmstadt, Germany
All rights reserved.
===============================================================================


Contents:
---------
  * Introduction
  * System Requirements
  * Contents of this directory
  * Installation of PCAN hardware
  * How to contact PEAK-System Technik GmbH
  * LIFE SUPPORT APPLIANCES


Introduction
------------
The PCAN system of the company PEAK-System Technik GmbH consists of a
collection of Device Drivers. These allow the Real-time connection of
applications to all CAN busses that are physically connected to the PC
via a PCAN hardware.

PCAN-Basic is a simple programming interface to the PCAN system. Via one
Interface DLL it is possible to connect own applications to the Device drivers
and the PCAN hardware, to communicate with the CAN busses.


System Requirements
-------------------
- PCAN Linux Driver: 8.0.17 and above
  (Driver for Linux can be download at www.peak-system.com/linux)


Contents of this directory
--------------------------
readme.txt
    This text file.

release_notes.txt
    Notes about the versions' changes.

\libpcanbasic
	\docs
		PCANBasic_enu.chm
			The PCAN-Basic documentation in English (Windows version).

		PCANBasic_deu.chm
			The PCAN-Basic documentation in German (Windows version).

		PCAN-Parameter_Documentation.pdf
			Additional documentation about PCAN-Basic Get/Set parameters in English (Windows version).
			
		PCANBasic_enu_linux_addenda.txt
			List of known differences between Linux and Windows documentation.

	\examples
		Contains example files that demonstrate the use of the PCAN-Basic API in
		different programming languages and development environments
		(will be enhanced in the future).
		
	\pcanbasic
		The interface DLL.

	
    \pcaninfo
        This tool lists all known PCAN devices and outputs information for each.

\pcanbasic_java
	\examples
		Contains example files that demonstrate the use of the PCAN-Basic API in
		different programming languages and development environments
		(will be enhanced in the future).
		
	\java
		Contains the Java files to use PCAN-Basic
		
	\javadoc
		Javadoc of the PCAN-Basic Java library
		
	\libpcanbasic_jni
		PCAN-Basic Java Native Interface.

Installation of PCAN-Basic library
----------------------------------
To build PCAN-Basic library:
> cd libpcanbasic/pcanbasic
> make clean
> make 

To install PCAN-Basic library (inside pcanbasic directory):
> sudo make install
(or as root "make install")

To uninstall PCAN-Basic library (inside pcanbasic directory):
> sudo make uninstall
(or as root "make uninstall")


To build PCAN-Basic JNI, follow the same process:
0. Install PCAN-Basic library first
1. Change the current working directory to PCAN-Basic_jni
> cd pcanbasic_java/libpcanbasic_jni
2. Build the application with "make"
3. Install the JNI library as root with "make install"
x. To uninstall the JNI library execute "make uninstall" as root


To build or install/uninstall extras and examples, follow the same process:
1. Change the current working directory
2. Build the application/sample with "make"
3. Install the application/sample as root with "make install"
x. Uninstall the application/sample as root with "make uninstall"


How to contact PEAK-System Technik GmbH
---------------------------------------
If you have any questions concerning the installation of PCAN hardware, or
require information about other PEAK CAN products, then please contact us:

PEAK-System Technik GmbH
Otto-Roehm-Str. 69
D-64293 Darmstadt
Germany

Tel. +49 6151 / 8173-20
FAX  +49 6151 / 8173-29

support@peak-system.com
http://www.peak-system.com


LIFE SUPPORT APPLIANCES
-----------------------
These products are not designed for use in life support appliances, devices,
or systems where malfunction of these products can reasonably be expected to
result in personal injury. PEAK-System customers using or selling these
products for use in such applications do so at their own risk and agree to
fully indemnify PEAK-System for any damages resulting from such improper use
or sale.
